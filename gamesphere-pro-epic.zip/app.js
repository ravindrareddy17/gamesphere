// Enhanced GameSphere Pro with EPIC LOGIN VFX - Developed by RAVINDRA REDDY
// Copyright 2025 - Premium Gaming Platform with Cinematic Experience

// Enhanced game data with more categories and realistic titles
const sampleGames = {
    action: [
        { title: 'Cyber Strike Elite', rating: 4.8, difficulty: 'Hard', trending: true },
        { title: 'Shadow Warrior', rating: 4.7, difficulty: 'Expert', trending: false },
        { title: 'Neon Combat', rating: 4.6, difficulty: 'Medium', trending: true },
        { title: 'Space Marine', rating: 4.5, difficulty: 'Hard', trending: false },
        { title: 'Battle Royale Supreme', rating: 4.9, difficulty: 'Expert', trending: true }
    ],
    rpg: [
        { title: 'Mystic Realms', rating: 4.9, difficulty: 'Hard', trending: true },
        { title: 'Dragon Quest Chronicles', rating: 4.8, difficulty: 'Medium', trending: false },
        { title: 'Fantasy Kingdom', rating: 4.7, difficulty: 'Hard', trending: true },
        { title: 'Dungeon Master', rating: 4.6, difficulty: 'Expert', trending: false },
        { title: 'Epic Adventure', rating: 4.8, difficulty: 'Medium', trending: false }
    ],
    strategy: [
        { title: 'Space Commander', rating: 4.7, difficulty: 'Hard', trending: false },
        { title: 'Empire Builder', rating: 4.6, difficulty: 'Expert', trending: true },
        { title: 'War Tactics', rating: 4.5, difficulty: 'Hard', trending: false },
        { title: 'City Planner', rating: 4.4, difficulty: 'Medium', trending: false },
        { title: 'Resource Manager', rating: 4.3, difficulty: 'Hard', trending: false }
    ],
    puzzle: [
        { title: 'Mind Bender', rating: 4.5, difficulty: 'Medium', trending: true },
        { title: 'Logic Master', rating: 4.6, difficulty: 'Hard', trending: false },
        { title: 'Color Match', rating: 4.3, difficulty: 'Easy', trending: true },
        { title: 'Number Wizard', rating: 4.4, difficulty: 'Medium', trending: false },
        { title: 'Pattern Solver', rating: 4.2, difficulty: 'Hard', trending: false }
    ],
    sports: [
        { title: 'Championship Soccer', rating: 4.4, difficulty: 'Medium', trending: true },
        { title: 'Basketball Pro', rating: 4.3, difficulty: 'Medium', trending: false },
        { title: 'Tennis Master', rating: 4.2, difficulty: 'Easy', trending: false },
        { title: 'Racing Champion', rating: 4.6, difficulty: 'Hard', trending: true },
        { title: 'Golf Pro', rating: 4.1, difficulty: 'Medium', trending: false }
    ],
    arcade: [
        { title: 'Retro Blast', rating: 4.5, difficulty: 'Easy', trending: true },
        { title: 'Pixel Runner', rating: 4.4, difficulty: 'Medium', trending: false },
        { title: 'Classic Shooter', rating: 4.3, difficulty: 'Easy', trending: true },
        { title: 'Coin Collector', rating: 4.2, difficulty: 'Easy', trending: false },
        { title: 'Speed Racer', rating: 4.4, difficulty: 'Medium', trending: false }
    ],
    multiplayer: [
        { title: 'Team Battle Arena', rating: 4.8, difficulty: 'Hard', trending: true },
        { title: 'Co-op Adventure', rating: 4.7, difficulty: 'Medium', trending: true },
        { title: 'PvP Champions', rating: 4.6, difficulty: 'Expert', trending: false },
        { title: 'Guild Wars', rating: 4.5, difficulty: 'Hard', trending: true },
        { title: 'Online Tournament', rating: 4.4, difficulty: 'Hard', trending: false }
    ],
    indie: [
        { title: 'Art of Gaming', rating: 4.3, difficulty: 'Medium', trending: false },
        { title: 'Creative Quest', rating: 4.4, difficulty: 'Easy', trending: true },
        { title: 'Indie Masterpiece', rating: 4.5, difficulty: 'Medium', trending: false },
        { title: 'Experimental Game', rating: 4.2, difficulty: 'Hard', trending: false },
        { title: 'Artistic Vision', rating: 4.1, difficulty: 'Medium', trending: false }
    ]
};

// Achievement system with 50+ achievements
const achievementsList = [
    // Beginner achievements
    { id: 'first_game', name: 'First Steps', description: 'Play your first game', icon: '🎮', rarity: 'Common', unlocked: false, progress: 0, target: 1 },
    { id: 'first_win', name: 'First Victory', description: 'Win your first game', icon: '🏆', rarity: 'Common', unlocked: false, progress: 0, target: 1 },
    { id: 'welcome', name: 'Welcome Gamer', description: 'Create your profile', icon: '👋', rarity: 'Common', unlocked: true, progress: 1, target: 1 },
    
    // Play count achievements
    { id: 'play_5', name: 'Getting Started', description: 'Play 5 different games', icon: '🌟', rarity: 'Common', unlocked: false, progress: 0, target: 5 },
    { id: 'play_10', name: 'Game Explorer', description: 'Play 10 different games', icon: '🗺️', rarity: 'Uncommon', unlocked: false, progress: 0, target: 10 },
    { id: 'play_25', name: 'Game Enthusiast', description: 'Play 25 different games', icon: '🎯', rarity: 'Uncommon', unlocked: false, progress: 0, target: 25 },
    { id: 'play_50', name: 'Game Connoisseur', description: 'Play 50 different games', icon: '🎨', rarity: 'Rare', unlocked: false, progress: 0, target: 50 },
    { id: 'play_100', name: 'Game Master', description: 'Play 100 different games', icon: '👑', rarity: 'Epic', unlocked: false, progress: 0, target: 100 },
    
    // Time-based achievements
    { id: 'hour_1', name: 'Casual Player', description: 'Play for 1 hour total', icon: '⏰', rarity: 'Common', unlocked: false, progress: 0, target: 60 },
    { id: 'hour_5', name: 'Dedicated Gamer', description: 'Play for 5 hours total', icon: '⏳', rarity: 'Uncommon', unlocked: false, progress: 0, target: 300 },
    { id: 'hour_10', name: 'Serious Player', description: 'Play for 10 hours total', icon: '🕐', rarity: 'Rare', unlocked: false, progress: 0, target: 600 },
    { id: 'marathon', name: 'Marathon Gamer', description: 'Play for 24 hours total', icon: '🏃', rarity: 'Epic', unlocked: false, progress: 0, target: 1440 },
    
    // Category achievements
    { id: 'action_fan', name: 'Action Hero', description: 'Play 10 action games', icon: '⚔️', rarity: 'Uncommon', unlocked: false, progress: 0, target: 10 },
    { id: 'rpg_master', name: 'RPG Master', description: 'Play 10 RPG games', icon: '🏰', rarity: 'Uncommon', unlocked: false, progress: 0, target: 10 },
    { id: 'puzzle_solver', name: 'Puzzle Solver', description: 'Play 10 puzzle games', icon: '🧩', rarity: 'Uncommon', unlocked: false, progress: 0, target: 10 },
    { id: 'strategy_mind', name: 'Strategic Mind', description: 'Play 10 strategy games', icon: '🧠', rarity: 'Uncommon', unlocked: false, progress: 0, target: 10 },
    { id: 'sports_star', name: 'Sports Star', description: 'Play 10 sports games', icon: '⚽', rarity: 'Uncommon', unlocked: false, progress: 0, target: 10 },
    { id: 'arcade_legend', name: 'Arcade Legend', description: 'Play 10 arcade games', icon: '🕹️', rarity: 'Uncommon', unlocked: false, progress: 0, target: 10 },
    
    // Social achievements
    { id: 'reviewer', name: 'Game Reviewer', description: 'Rate 10 games', icon: '⭐', rarity: 'Uncommon', unlocked: false, progress: 0, target: 10 },
    { id: 'social_butterfly', name: 'Social Butterfly', description: 'Add 5 games to favorites', icon: '🦋', rarity: 'Uncommon', unlocked: false, progress: 0, target: 5 },
    
    // Completion achievements
    { id: 'completionist', name: 'Completionist', description: 'Complete 50 games', icon: '💯', rarity: 'Epic', unlocked: false, progress: 0, target: 50 },
    { id: 'perfectionist', name: 'Perfectionist', description: 'Get 5-star rating in 20 games', icon: '⭐', rarity: 'Epic', unlocked: false, progress: 0, target: 20 },
    
    // Streak achievements
    { id: 'streak_3', name: 'Getting Consistent', description: 'Play games for 3 days in a row', icon: '🔥', rarity: 'Uncommon', unlocked: false, progress: 0, target: 3 },
    { id: 'streak_7', name: 'Weekly Warrior', description: 'Play games for 7 days in a row', icon: '📅', rarity: 'Rare', unlocked: false, progress: 0, target: 7 },
    { id: 'streak_30', name: 'Monthly Champion', description: 'Play games for 30 days in a row', icon: '🗓️', rarity: 'Epic', unlocked: false, progress: 0, target: 30 },
    
    // Special achievements
    { id: 'night_owl', name: 'Night Owl', description: 'Play a game after midnight', icon: '🦉', rarity: 'Rare', unlocked: false, progress: 0, target: 1 },
    { id: 'early_bird', name: 'Early Bird', description: 'Play a game before 6 AM', icon: '🐦', rarity: 'Rare', unlocked: false, progress: 0, target: 1 },
    { id: 'speed_runner', name: 'Speed Runner', description: 'Complete a game in under 5 minutes', icon: '💨', rarity: 'Epic', unlocked: false, progress: 0, target: 1 },
    { id: 'explorer', name: 'Game Explorer', description: 'Try games from all categories', icon: '🗺️', rarity: 'Epic', unlocked: false, progress: 0, target: 8 },
    
    // Platform achievements
    { id: 'mobile_gamer', name: 'Mobile Gamer', description: 'Play 10 games on mobile', icon: '📱', rarity: 'Uncommon', unlocked: false, progress: 0, target: 10 },
    { id: 'desktop_master', name: 'Desktop Master', description: 'Play 20 games on desktop', icon: '🖥️', rarity: 'Uncommon', unlocked: false, progress: 0, target: 20 },
    
    // Legendary achievements
    { id: 'legend', name: 'Gaming Legend', description: 'Unlock 40 other achievements', icon: '👑', rarity: 'Legendary', unlocked: false, progress: 0, target: 40 },
    { id: 'developer_fan', name: 'RAVINDRA REDDY Fan', description: 'Play for 100 hours on GameSphere Pro', icon: '💎', rarity: 'Legendary', unlocked: false, progress: 0, target: 6000 },
    { id: 'platform_master', name: 'Platform Master', description: 'Experience all features of GameSphere Pro', icon: '🏆', rarity: 'Legendary', unlocked: false, progress: 0, target: 1 }
];

// Global state
let currentUser = null;
let allGames = [];
let filteredGames = [];
let displayedGames = [];
let gameHistory = [];
let favoriteGames = [];
let userAchievements = [...achievementsList];
let loadedGamesCount = 0;
const gamesPerLoad = 20;
let currentAuthTab = 'login';
let featuredGame = null;
let trendingGames = [];

// Epic VFX state
let epicVFXActive = false;
let screenShakeTimer = null;
let bgmSimulationTimer = null;
let introCompleted = false;

// Categories with enhanced data
const categories = [
    { name: 'All', icon: '🎮', count: 0 },
    { name: 'Action', icon: '⚔️', count: 200 },
    { name: 'RPG', icon: '🏰', count: 150 },
    { name: 'Strategy', icon: '🧠', count: 100 },
    { name: 'Puzzle', icon: '🧩', count: 150 },
    { name: 'Sports', icon: '⚽', count: 100 },
    { name: 'Arcade', icon: '🕹️', count: 100 },
    { name: 'Multiplayer', icon: '👥', count: 100 },
    { name: 'Indie', icon: '🎨', count: 100 }
];

// Game URLs for better variety
const gameUrls = [
    'https://html5games.com/Game/space-invaders/',
    'https://html5games.com/Game/tetris/',
    'https://html5games.com/Game/pacman/',
    'https://html5games.com/Game/snake/',
    'https://html5.gamedistribution.com/rvvASMiM/405c00610e7d43c98df6b1c6b20e7af5/',
    'https://www.crazygames.com/embed/subway-surfers',
    'https://www.miniclip.com/games/en/'
];

// Initialize the application
function init() {
    console.log('🎮 Initializing GameSphere Pro with EPIC VFX...');
    console.log('👨‍💻 Developed by RAVINDRA REDDY');
    console.log('🔥 EPIC LOGIN VFX ACTIVATED!');
    
    // Ensure intro screen is visible
    const introScreen = document.getElementById('introScreen');
    if (introScreen) {
        introScreen.style.display = 'flex';
        console.log('✅ Intro screen is visible');
    }
    
    // Hide app elements initially
    hideApp();
    
    // Load games first
    loadGames().then(() => {
        console.log('✅ Games loaded successfully');
        // Initialize other components after games are loaded
        initializeAchievements();
        populateCategories();
        setFeaturedGame();
    });
    
    // Setup event listeners first
    setupEventListeners();
    
    // Initialize epic VFX
    initializeEpicVFX();
    
    // Start cinematic intro after a brief delay
    setTimeout(() => {
        startCinematicIntro();
    }, 100);
}

function initializeEpicVFX() {
    console.log('⚡ Initializing EPIC VFX System...');
    
    // Add CSS animations for VFX
    if (!document.getElementById('epicVFXStyles')) {
        const epicVFXStyles = document.createElement('style');
        epicVFXStyles.id = 'epicVFXStyles';
        epicVFXStyles.textContent = `
            @keyframes quickFlash {
                0% { opacity: 0; transform: translateY(-50%) scale(0); }
                50% { opacity: 1; transform: translateY(-50%) scale(1.5); }
                100% { opacity: 0; transform: translateY(-50%) scale(0); }
            }
            
            @keyframes typingTrail {
                0% { transform: translateY(-50%) translateX(-100%); opacity: 0; }
                50% { opacity: 1; }
                100% { transform: translateY(-50%) translateX(100%); opacity: 0; }
            }
            
            @keyframes victoryFlash {
                0% { opacity: 0; transform: scale(0); }
                50% { opacity: 1; transform: scale(1.2); }
                100% { opacity: 0; transform: scale(2); }
            }
            
            @keyframes errorFlash {
                0%, 100% { opacity: 0; }
                50% { opacity: 1; }
            }
        `;
        document.head.appendChild(epicVFXStyles);
    }
}

function startBGMSimulation() {
    if (bgmSimulationTimer) clearInterval(bgmSimulationTimer);
    
    console.log('🎵 Starting BGM Simulation...');
    
    bgmSimulationTimer = setInterval(() => {
        // Trigger random bass drops and rhythm pulses
        if (Math.random() > 0.7) {
            triggerBassDropEffect();
        }
        
        if (Math.random() > 0.6) {
            triggerRhythmPulse();
        }
    }, 1500);
}

function stopBGMSimulation() {
    if (bgmSimulationTimer) {
        clearInterval(bgmSimulationTimer);
        bgmSimulationTimer = null;
        console.log('🎵 BGM Simulation stopped');
    }
}

function triggerBassDropEffect() {
    const modal = document.getElementById('authModal');
    if (!modal || !modal.classList.contains('active')) return;
    
    console.log('💥 BASS DROP EFFECT!');
    
    // Screen shake effect
    modal.classList.add('screen-shake');
    setTimeout(() => {
        modal.classList.remove('screen-shake');
    }, 800);
    
    // Intensify all animations temporarily
    const allAnimatedElements = modal.querySelectorAll('.muzzle-flash, .explosion, .racing-car');
    allAnimatedElements.forEach(element => {
        const originalDuration = element.style.animationDuration;
        element.style.animationDuration = '0.3s';
        setTimeout(() => {
            element.style.animationDuration = originalDuration;
        }, 1000);
    });
}

function triggerRhythmPulse() {
    const modal = document.getElementById('authModal');
    if (!modal || !modal.classList.contains('active')) return;
    
    // Pulse the entire modal content
    const modalContent = modal.querySelector('.epic-content');
    if (modalContent && typeof gsap !== 'undefined') {
        gsap.to(modalContent, {
            scale: 1.02,
            duration: 0.2,
            yoyo: true,
            repeat: 1,
            ease: 'power2.inOut'
        });
    }
    
    // Sync visual elements with the beat
    const rhythmElements = modal.querySelectorAll('.rhythm-pulse, .bass-bar');
    rhythmElements.forEach((element, index) => {
        setTimeout(() => {
            const originalDuration = element.style.animationDuration;
            element.style.animationDuration = '0.5s';
            setTimeout(() => {
                element.style.animationDuration = originalDuration;
            }, 600);
        }, index * 100);
    });
}

function setupEventListeners() {
    console.log('Setting up enhanced event listeners...');
    
    // Intro
    const skipIntroBtn = document.getElementById('skipIntro');
    if (skipIntroBtn) {
        skipIntroBtn.addEventListener('click', skipIntro);
    }
    
    // Auth modal
    document.querySelectorAll('.auth-tab').forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            switchAuthTab(this.dataset.tab);
            
            // Epic tab switch effect
            triggerTabSwitchVFX(this);
        });
    });
    
    // Auth forms with EPIC VFX
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', handleEpicLogin);
    }
    if (signupForm) {
        signupForm.addEventListener('submit', handleEpicSignup);
    }
    
    // Close auth modal
    const closeAuthModal = document.getElementById('closeAuthModal');
    if (closeAuthModal) {
        closeAuthModal.addEventListener('click', () => {
            triggerVictoryExplosion();
            setTimeout(() => hideModal('authModal'), 300);
        });
    }
    
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const view = this.dataset.view;
            if (view) {
                console.log('Navigation clicked:', view);
                switchView(view);
            }
        });
    });
    
    // Footer navigation
    document.querySelectorAll('.footer-links a[data-view]').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const view = this.dataset.view;
            if (view) switchView(view);
        });
    });
    
    // Logout
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', logout);
    }
    
    // Game controls
    const gameSearch = document.getElementById('gameSearch');
    if (gameSearch) {
        gameSearch.addEventListener('input', function(e) {
            handleSearch(e.target.value);
        });
    }
    
    const categoryFilter = document.getElementById('categoryFilter');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', function(e) {
            handleCategoryFilter(e.target.value);
        });
    }
    
    const difficultyFilter = document.getElementById('difficultyFilter');
    if (difficultyFilter) {
        difficultyFilter.addEventListener('change', function(e) {
            handleDifficultyFilter(e.target.value);
        });
    }
    
    const sortFilter = document.getElementById('sortFilter');
    if (sortFilter) {
        sortFilter.addEventListener('change', function(e) {
            handleSort(e.target.value);
        });
    }
    
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', loadMoreGames);
    }
    
    // Game player modal
    const closeGamePlayer = document.getElementById('closeGamePlayer');
    if (closeGamePlayer) {
        closeGamePlayer.addEventListener('click', closeGamePlayerModal);
    }
    
    const fullscreenBtn = document.getElementById('fullscreenBtn');
    if (fullscreenBtn) {
        fullscreenBtn.addEventListener('click', toggleFullscreen);
    }
    
    const favoriteBtn = document.getElementById('favoriteBtn');
    if (favoriteBtn) {
        favoriteBtn.addEventListener('click', toggleFavorite);
    }
    
    // History
    const clearHistoryBtn = document.getElementById('clearHistoryBtn');
    if (clearHistoryBtn) {
        clearHistoryBtn.addEventListener('click', clearHistory);
    }
    
    const historyFilter = document.getElementById('historyFilter');
    if (historyFilter) {
        historyFilter.addEventListener('change', handleHistoryFilter);
    }
    
    // Modal backdrop clicks
    document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
        backdrop.addEventListener('click', function(e) {
            if (e.target === this) {
                const modal = e.target.parentElement;
                hideModal(modal.id);
            }
        });
    });
    
    // Setup EPIC input handlers after DOM is ready
    setTimeout(() => {
        setupEpicInputHandlers();
    }, 100);
}

function setupEpicInputHandlers() {
    console.log('⚡ Setting up EPIC input handlers...');
    
    // Enhanced input interactions
    document.querySelectorAll('.epic-input').forEach(input => {
        console.log('Setting up epic input:', input.id);
        
        input.addEventListener('focus', handleEpicInputFocus);
        input.addEventListener('blur', handleEpicInputBlur);
        input.addEventListener('input', handleEpicInputChange);
        input.addEventListener('keydown', handleEpicInputKeydown);
    });
}

// EPIC INPUT HANDLERS
function handleEpicInputFocus(e) {
    const input = e.target;
    const container = input.closest('.epic-input-container');
    
    console.log('⚡ Epic input focus triggered!', input.id);
    
    if (container) {
        // Trigger particle effect
        const particles = container.querySelector('.input-particles');
        if (particles) {
            particles.style.opacity = '1';
        }
        
        // Muzzle flash effect
        triggerInputMuzzleFlash(container);
        
        // Screen shake
        triggerMiniScreenShake();
    }
}

function handleEpicInputBlur(e) {
    const input = e.target;
    const container = input.closest('.epic-input-container');
    
    if (container) {
        const particles = container.querySelector('.input-particles');
        if (particles) {
            particles.style.opacity = '0';
        }
    }
}

function handleEpicInputChange(e) {
    const input = e.target;
    
    // Trigger typing VFX on each keystroke
    if (Math.random() > 0.5) { // 50% chance per keystroke
        triggerTypingVFX(input);
    }
    
    console.log('⚡ Typing VFX triggered for:', input.id);
}

function handleEpicInputKeydown(e) {
    // Trigger more intense effects on Enter key
    if (e.key === 'Enter') {
        triggerInputExplosion(e.target);
    }
}

function triggerInputMuzzleFlash(container) {
    console.log('💥 Triggering input muzzle flash!');
    
    // Create temporary muzzle flash effect
    const flash = document.createElement('div');
    flash.className = 'temp-muzzle-flash';
    flash.style.cssText = `
        position: absolute;
        top: 50%;
        right: 10px;
        transform: translateY(-50%);
        width: 20px;
        height: 20px;
        background: radial-gradient(circle, #FFD700 0%, #FF6B35 50%, transparent 100%);
        border-radius: 50%;
        pointer-events: none;
        z-index: 10;
        animation: quickFlash 0.3s ease-out;
    `;
    
    container.appendChild(flash);
    
    setTimeout(() => {
        if (flash.parentNode) {
            flash.parentNode.removeChild(flash);
        }
    }, 300);
}

function triggerTypingVFX(input) {
    const container = input.closest('.epic-input-container');
    if (!container) return;
    
    console.log('⚡ Triggering typing VFX!');
    
    // Create bullet trail effect
    const trail = document.createElement('div');
    trail.className = 'typing-trail';
    trail.style.cssText = `
        position: absolute;
        top: 50%;
        left: 0;
        width: 100%;
        height: 2px;
        background: linear-gradient(90deg, transparent, #00E5FF, transparent);
        transform: translateY(-50%);
        pointer-events: none;
        z-index: 5;
        animation: typingTrail 0.4s ease-out;
    `;
    
    container.appendChild(trail);
    
    setTimeout(() => {
        if (trail.parentNode) {
            trail.parentNode.removeChild(trail);
        }
    }, 400);
}

function triggerInputExplosion(input) {
    console.log('💥 Input explosion triggered!');
    
    const container = input.closest('.epic-input-container');
    if (!container) return;
    
    // Create explosion effect
    const explosion = document.createElement('div');
    explosion.style.cssText = `
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 60px;
        height: 60px;
        background: radial-gradient(circle, #FFD700 0%, #FF6B35 30%, transparent 70%);
        border-radius: 50%;
        pointer-events: none;
        z-index: 15;
        animation: victoryFlash 0.6s ease-out;
    `;
    
    container.appendChild(explosion);
    
    setTimeout(() => {
        if (explosion.parentNode) {
            explosion.parentNode.removeChild(explosion);
        }
    }, 600);
}

function triggerMiniScreenShake() {
    const modal = document.getElementById('authModal');
    if (!modal) return;
    
    if (typeof gsap !== 'undefined') {
        gsap.to(modal, {
            x: 2,
            duration: 0.1,
            yoyo: true,
            repeat: 3,
            ease: 'power2.inOut',
            onComplete: () => {
                gsap.set(modal, { x: 0 });
            }
        });
    }
}

function triggerTabSwitchVFX(tab) {
    console.log('🏁 Epic tab switch VFX triggered!');
    
    // Epic explosion effect on tab switch
    const explosion = tab.querySelector('.tab-explosion');
    if (explosion && typeof gsap !== 'undefined') {
        gsap.fromTo(explosion, 
            { scale: 0, opacity: 0 },
            { scale: 2, opacity: 0.6, duration: 0.4, ease: 'power2.out' }
        ).then(() => {
            gsap.to(explosion, { 
                scale: 3, 
                opacity: 0, 
                duration: 0.3, 
                ease: 'power2.in' 
            });
        });
    }
    
    // Trigger racing car effect
    triggerRacingCarPassed();
}

function triggerRacingCarPassed() {
    const modal = document.getElementById('authModal');
    if (!modal) return;
    
    const racingCars = modal.querySelectorAll('.racing-car');
    racingCars.forEach(car => {
        const originalDuration = car.style.animationDuration;
        car.style.animationDuration = '0.8s';
        setTimeout(() => {
            car.style.animationDuration = originalDuration;
        }, 1000);
    });
}

// EPIC FORM HANDLERS
function handleEpicLogin(e) {
    e.preventDefault();
    console.log('🔐 Handling EPIC login...');
    
    const email = document.getElementById('loginEmail')?.value;
    const password = document.getElementById('loginPassword')?.value;
    
    if (!email || !password) {
        triggerErrorShake();
        alert('Please fill in all fields to experience the EPIC login!');
        return;
    }
    
    // Trigger massive explosion effect
    triggerLoginExplosion();
    
    // Create user
    currentUser = {
        username: email.split('@')[0],
        email: email,
        joinDate: new Date().toISOString(),
        level: 1,
        xp: 0,
        totalPlayTime: 0,
        currentStreak: 0,
        lastPlayDate: null
    };
    
    // Unlock welcome achievement
    unlockAchievement('welcome');
    
    // Epic login sequence
    setTimeout(() => {
        triggerVictoryExplosion();
        setTimeout(() => {
            hideModal('authModal');
            showApp();
            console.log('✅ EPIC Login successful for:', currentUser.username);
        }, 1000);
    }, 1500);
}

function handleEpicSignup(e) {
    e.preventDefault();
    console.log('📝 Handling EPIC signup...');
    
    const username = document.getElementById('signupUsername')?.value;
    const email = document.getElementById('signupEmail')?.value;
    const password = document.getElementById('signupPassword')?.value;
    
    if (!username || !email || !password) {
        triggerErrorShake();
        alert('Please fill in all fields to join the EPIC experience!');
        return;
    }
    
    // Trigger massive explosion effect
    triggerLoginExplosion();
    
    // Create user
    currentUser = {
        username: username,
        email: email,
        joinDate: new Date().toISOString(),
        level: 1,
        xp: 0,
        totalPlayTime: 0,
        currentStreak: 0,
        lastPlayDate: null
    };
    
    // Unlock welcome achievement
    unlockAchievement('welcome');
    
    // Epic signup sequence
    setTimeout(() => {
        triggerVictoryExplosion();
        setTimeout(() => {
            hideModal('authModal');
            showApp();
            console.log('✅ EPIC Signup successful for:', currentUser.username);
        }, 1000);
    }, 1500);
}

function triggerLoginExplosion() {
    const modal = document.getElementById('authModal');
    if (!modal) return;
    
    console.log('💥 TRIGGERING MASSIVE LOGIN EXPLOSION!');
    
    // Massive screen shake
    modal.classList.add('screen-shake');
    
    // Trigger all explosions at once
    const explosions = modal.querySelectorAll('.explosion');
    explosions.forEach((explosion, index) => {
        explosion.style.animationDelay = `${index * 0.1}s`;
        explosion.style.animationDuration = '0.6s';
    });
    
    // Muzzle flashes
    const flashes = modal.querySelectorAll('.muzzle-flash');
    flashes.forEach((flash, index) => {
        flash.style.animationDelay = `${index * 0.05}s`;
        flash.style.animationDuration = '0.3s';
    });
    
    // Racing cars zoom by
    const cars = modal.querySelectorAll('.racing-car');
    cars.forEach(car => {
        car.style.animationDuration = '0.5s';
    });
    
    // Reset after explosion
    setTimeout(() => {
        modal.classList.remove('screen-shake');
        explosions.forEach(explosion => {
            explosion.style.animationDelay = '';
            explosion.style.animationDuration = '';
        });
        flashes.forEach(flash => {
            flash.style.animationDelay = '';
            flash.style.animationDuration = '';
        });
        cars.forEach(car => {
            car.style.animationDuration = '';
        });
    }, 2000);
}

function triggerVictoryExplosion() {
    const modal = document.getElementById('authModal');
    if (!modal) return;
    
    console.log('🎉 VICTORY EXPLOSION SEQUENCE INITIATED!');
    
    // Create victory explosion overlay
    const victoryOverlay = document.createElement('div');
    victoryOverlay.style.cssText = `
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: radial-gradient(circle, rgba(255, 215, 0, 0.8) 0%, rgba(255, 107, 53, 0.6) 30%, rgba(255, 23, 68, 0.4) 60%, transparent 100%);
        z-index: 1000;
        pointer-events: none;
        animation: victoryFlash 1s ease-out;
    `;
    
    modal.appendChild(victoryOverlay);
    
    // Massive screen shake
    if (typeof gsap !== 'undefined') {
        gsap.to(modal, {
            x: 10,
            y: 5,
            rotation: 1,
            duration: 0.1,
            yoyo: true,
            repeat: 9,
            ease: 'power2.inOut',
            onComplete: () => {
                gsap.set(modal, { x: 0, y: 0, rotation: 0 });
            }
        });
    }
    
    // Remove victory overlay
    setTimeout(() => {
        if (victoryOverlay.parentNode) {
            victoryOverlay.parentNode.removeChild(victoryOverlay);
        }
    }, 1000);
}

function triggerErrorShake() {
    const modal = document.getElementById('authModal');
    if (!modal) return;
    
    console.log('❌ ERROR SHAKE EFFECT!');
    
    if (typeof gsap !== 'undefined') {
        gsap.to(modal, {
            x: -10,
            duration: 0.1,
            yoyo: true,
            repeat: 5,
            ease: 'power2.inOut',
            onComplete: () => {
                gsap.set(modal, { x: 0 });
            }
        });
    }
    
    // Flash red error
    const errorFlash = document.createElement('div');
    errorFlash.style.cssText = `
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 23, 68, 0.3);
        z-index: 999;
        pointer-events: none;
        animation: errorFlash 0.3s ease-out;
    `;
    
    modal.appendChild(errorFlash);
    
    setTimeout(() => {
        if (errorFlash.parentNode) {
            errorFlash.parentNode.removeChild(errorFlash);
        }
    }, 300);
}

function startCinematicIntro() {
    console.log('🎬 Starting cinematic intro...');
    
    // Initialize particle canvas
    initParticleCanvas();
    
    // Check if GSAP is available
    if (typeof gsap === 'undefined') {
        console.log('GSAP not loaded, using fallback animation');
        setTimeout(completeIntro, 4000);
        return;
    }
    
    // Enhanced GSAP Timeline for intro
    const tl = gsap.timeline({
        onComplete: completeIntro
    });
    
    // Logo animation sequence
    tl.to('.intro-logo', {
        opacity: 1,
        scale: 1,
        y: 0,
        duration: 2,
        ease: 'power3.out'
    })
    .to('.intro-tagline', {
        opacity: 1,
        y: 0,
        duration: 1.2,
        ease: 'power2.out'
    }, '-=0.8')
    .to('.developer-credit', {
        opacity: 1,
        y: 0,
        duration: 1,
        ease: 'power2.out'
    }, '-=0.6')
    .to('.intro-progress', {
        opacity: 1,
        duration: 0.8
    }, '-=0.4')
    .to('.intro-screen', {
        opacity: 0,
        scale: 0.95,
        duration: 1.5,
        ease: 'power2.inOut',
        delay: 2
    });
}

function initParticleCanvas() {
    const canvas = document.getElementById('particleCanvas');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const particles = [];
    const particleCount = 150;
    
    // Create enhanced particles
    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 1.5,
            vy: (Math.random() - 0.5) * 1.5,
            size: Math.random() * 4 + 1,
            opacity: Math.random() * 0.6 + 0.1,
            color: Math.random() > 0.5 ? 'rgba(50, 184, 198, ' : 'rgba(33, 128, 141, ',
            pulsate: Math.random() * 0.02 + 0.01
        });
    }
    
    let time = 0;
    
    // Enhanced particle animation
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        time += 0.01;
        
        particles.forEach((particle, index) => {
            // Update position
            particle.x += particle.vx;
            particle.y += particle.vy;
            
            // Wrap around edges
            if (particle.x < 0) particle.x = canvas.width;
            if (particle.x > canvas.width) particle.x = 0;
            if (particle.y < 0) particle.y = canvas.height;
            if (particle.y > canvas.height) particle.y = 0;
            
            // Pulsating effect
            const pulse = Math.sin(time + index * 0.1) * 0.3 + 0.7;
            
            // Draw particle
            ctx.globalAlpha = particle.opacity * pulse;
            ctx.fillStyle = particle.color + particle.opacity + ')';
            ctx.beginPath();
            ctx.arc(particle.x, particle.y, particle.size * pulse, 0, Math.PI * 2);
            ctx.fill();
            
            // Draw connections to nearby particles
            particles.forEach((otherParticle, otherIndex) => {
                if (index === otherIndex) return;
                
                const dx = particle.x - otherParticle.x;
                const dy = particle.y - otherParticle.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < 100) {
                    ctx.globalAlpha = (1 - distance / 100) * 0.1;
                    ctx.strokeStyle = 'rgba(50, 184, 198, 0.3)';
                    ctx.lineWidth = 1;
                    ctx.beginPath();
                    ctx.moveTo(particle.x, particle.y);
                    ctx.lineTo(otherParticle.x, otherParticle.y);
                    ctx.stroke();
                }
            });
        });
        
        requestAnimationFrame(animate);
    }
    
    animate();
}

function skipIntro() {
    console.log('Skipping intro...');
    if (typeof gsap !== 'undefined') {
        gsap.killTweensOf('.intro-screen');
    }
    completeIntro();
}

function completeIntro() {
    console.log('🎬 Intro complete - Welcome to GameSphere Pro!');
    introCompleted = true;
    
    const introScreen = document.getElementById('introScreen');
    if (introScreen) {
        introScreen.style.display = 'none';
    }
    
    // Show auth modal if no user with EPIC entrance
    if (!currentUser) {
        console.log('🎭 Showing EPIC login modal...');
        showModal('authModal');
    } else {
        showApp();
    }
}

function switchAuthTab(tab) {
    console.log('Switching to auth tab:', tab);
    
    try {
        currentAuthTab = tab;
        
        // Update tab appearance
        document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
        const activeTab = document.querySelector(`[data-tab="${tab}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
        }
        
        // Switch forms
        document.querySelectorAll('.auth-form').forEach(form => form.classList.add('hidden'));
        const targetForm = document.getElementById(`${tab}Form`);
        if (targetForm) {
            targetForm.classList.remove('hidden');
        }
        
    } catch (error) {
        console.error('Error switching auth tab:', error);
    }
}

function logout() {
    console.log('👋 Logging out user:', currentUser?.username);
    currentUser = null;
    gameHistory = [];
    favoriteGames = [];
    userAchievements = [...achievementsList];
    hideApp();
    showModal('authModal');
}

function showApp() {
    console.log('🎮 Showing main app...');
    
    const navbar = document.getElementById('navbar');
    const appContainer = document.getElementById('appContainer');
    const appFooter = document.getElementById('appFooter');
    
    if (navbar) navbar.classList.remove('hidden');
    if (appContainer) appContainer.classList.remove('hidden');
    if (appFooter) appFooter.classList.remove('hidden');
    
    if (currentUser) {
        const navUserName = document.getElementById('navUserName');
        if (navUserName) {
            navUserName.textContent = currentUser.username;
        }
    }
    
    // Always switch to library view first
    switchView('library');
}

function hideApp() {
    const navbar = document.getElementById('navbar');
    const appContainer = document.getElementById('appContainer');
    const appFooter = document.getElementById('appFooter');
    
    if (navbar) navbar.classList.add('hidden');
    if (appContainer) appContainer.classList.add('hidden');
    if (appFooter) appFooter.classList.add('hidden');
}

function switchView(viewName) {
    console.log('🔄 Switching to view:', viewName);
    
    // Update navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.dataset.view === viewName) {
            link.classList.add('active');
        }
    });
    
    // Hide all views
    document.querySelectorAll('.view').forEach(view => {
        view.classList.remove('active');
    });
    
    // Show selected view
    const targetView = document.getElementById(`${viewName}View`);
    if (targetView) {
        targetView.classList.add('active');
        console.log('✅ View switched to:', viewName);
        
        // Load view-specific content
        switch (viewName) {
            case 'library':
                renderInitialGames();
                break;
            case 'profile':
                updateProfile();
                break;
            case 'history':
                updateHistory();
                break;
            case 'achievements':
                updateAchievements();
                break;
        }
    } else {
        console.error('View not found:', viewName);
    }
}

async function loadGames() {
    console.log('🎮 Loading games database...');
    
    return new Promise((resolve) => {
        const games = [];
        let gameId = 1;
        
        // Generate games from sample data
        Object.entries(sampleGames).forEach(([category, categoryGames]) => {
            const categoryName = category.charAt(0).toUpperCase() + category.slice(1);
            const targetCount = categories.find(c => c.name === categoryName)?.count || 100;
            
            // Add base games
            categoryGames.forEach(game => {
                games.push({
                    id: `game_${gameId++}`,
                    title: game.title,
                    category: categoryName,
                    rating: game.rating,
                    difficulty: game.difficulty,
                    trending: game.trending,
                    image: `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 1000000)}?w=400&h=300&fit=crop&auto=format`,
                    url: gameUrls[Math.floor(Math.random() * gameUrls.length)],
                    description: `Experience amazing ${categoryName.toLowerCase()} gameplay with stunning graphics and engaging mechanics.`,
                    players: Math.random() > 0.5 ? 'Single Player' : 'Multiplayer',
                    duration: Math.floor(Math.random() * 120) + 15, // 15-135 minutes
                    releaseYear: 2020 + Math.floor(Math.random() * 5)
                });
            });
            
            // Generate additional games to reach target count
            for (let i = categoryGames.length; i < targetCount; i++) {
                const adjectives = ['Epic', 'Ultimate', 'Super', 'Mega', 'Classic', 'Modern', 'Advanced', 'Pro', 'Elite', 'Master'];
                const nouns = ['Quest', 'Adventure', 'Challenge', 'Battle', 'Arena', 'World', 'Strike', 'Force', 'Legend', 'Champion'];
                
                const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
                const noun = nouns[Math.floor(Math.random() * nouns.length)];
                
                games.push({
                    id: `game_${gameId++}`,
                    title: `${adj} ${noun} ${i + 1}`,
                    category: categoryName,
                    rating: +(Math.random() * 2 + 3).toFixed(1), // 3.0 - 5.0
                    difficulty: ['Easy', 'Medium', 'Hard', 'Expert'][Math.floor(Math.random() * 4)],
                    trending: Math.random() > 0.8,
                    image: `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 1000000)}?w=400&h=300&fit=crop&auto=format`,
                    url: gameUrls[Math.floor(Math.random() * gameUrls.length)],
                    description: `Exciting ${categoryName.toLowerCase()} game with immersive gameplay and cutting-edge features.`,
                    players: Math.random() > 0.5 ? 'Single Player' : 'Multiplayer',
                    duration: Math.floor(Math.random() * 120) + 15,
                    releaseYear: 2020 + Math.floor(Math.random() * 5)
                });
            }
        });
        
        allGames = games;
        filteredGames = [...allGames];
        
        console.log(`✅ Loaded ${allGames.length} premium games`);
        updateGameCount();
        resolve();
    });
}

function setFeaturedGame() {
    // Select a random trending game as featured
    const trendingGamesList = allGames.filter(game => game.trending);
    if (trendingGamesList.length > 0) {
        featuredGame = trendingGamesList[Math.floor(Math.random() * trendingGamesList.length)];
        renderFeaturedGame();
    }
    
    // Set trending games (top 6 trending games)
    trendingGames = trendingGamesList.slice(0, 6);
    renderTrendingGames();
}

function renderFeaturedGame() {
    const container = document.getElementById('featuredGame');
    if (!container || !featuredGame) return;
    
    container.innerHTML = `
        <div class="featured-game-content" style="display: flex; gap: var(--space-24); align-items: center; background: var(--color-bg-1); padding: var(--space-24); border-radius: var(--radius-lg); border: 2px solid var(--color-primary);">
            <div class="featured-game-image" style="flex-shrink: 0; width: 200px; height: 150px; border-radius: var(--radius-base); overflow: hidden; position: relative;">
                <img src="${featuredGame.image}" alt="${featuredGame.title}" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy">
                <div class="featured-overlay" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center; opacity: 0; transition: opacity 0.3s;">
                    <button class="btn btn--primary btn--lg" onclick="playGame('${featuredGame.id}')">
                        ▶ Play Featured Game
                    </button>
                </div>
            </div>
            <div class="featured-game-info" style="flex: 1;">
                <div class="featured-category" style="color: var(--color-primary); font-weight: var(--font-weight-bold); margin-bottom: var(--space-8);">${featuredGame.category}</div>
                <h3 style="margin-bottom: var(--space-12); font-size: var(--font-size-2xl);">${featuredGame.title}</h3>
                <p style="color: var(--color-text-secondary); margin-bottom: var(--space-16);">${featuredGame.description}</p>
                <div class="featured-stats" style="display: flex; gap: var(--space-16);">
                    <span class="rating">⭐ ${featuredGame.rating}</span>
                    <span class="difficulty">🎯 ${featuredGame.difficulty}</span>
                    <span class="duration">⏱️ ${featuredGame.duration} min</span>
                </div>
            </div>
        </div>
    `;
    
    // Add hover effect
    const featuredContent = container.querySelector('.featured-game-content');
    const overlay = container.querySelector('.featured-overlay');
    
    if (featuredContent && overlay) {
        featuredContent.addEventListener('mouseenter', () => {
            overlay.style.opacity = '1';
        });
        
        featuredContent.addEventListener('mouseleave', () => {
            overlay.style.opacity = '0';
        });
    }
}

function renderTrendingGames() {
    const container = document.getElementById('trendingGames');
    if (!container || trendingGames.length === 0) return;
    
    container.innerHTML = trendingGames.map(game => `
        <div class="trending-game-card" onclick="playGame('${game.id}')" style="background: var(--color-surface); border-radius: var(--radius-lg); overflow: hidden; cursor: pointer; transition: transform 0.3s; border: 2px solid var(--color-card-border);">
            <div class="trending-image" style="height: 120px; overflow: hidden; position: relative;">
                <img src="${game.image}" alt="${game.title}" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy">
                <div class="trending-overlay" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(var(--color-primary-rgb, 33, 128, 141), 0.9); color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; opacity: 0; transition: opacity 0.3s;">▶</div>
            </div>
            <div class="trending-info" style="padding: var(--space-16);">
                <h4 style="margin-bottom: var(--space-8); font-size: var(--font-size-lg);">${game.title}</h4>
                <div class="trending-rating" style="color: var(--color-warning);">⭐ ${game.rating}</div>
            </div>
        </div>
    `).join('');
    
    // Add hover effects
    container.querySelectorAll('.trending-game-card').forEach(card => {
        const overlay = card.querySelector('.trending-overlay');
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-5px)';
            if (overlay) overlay.style.opacity = '1';
        });
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
            if (overlay) overlay.style.opacity = '0';
        });
    });
}

function populateCategories() {
    const categoryFilter = document.getElementById('categoryFilter');
    if (!categoryFilter) return;
    
    categoryFilter.innerHTML = categories.map(category => 
        `<option value="${category.name}">${category.icon} ${category.name} ${category.name !== 'All' ? `(${category.count})` : ''}</option>`
    ).join('');
}

function renderInitialGames() {
    console.log('🎮 Rendering initial games...');
    loadedGamesCount = 0;
    displayedGames = [];
    
    // Ensure featured and trending games are rendered
    if (!featuredGame && allGames.length > 0) {
        setFeaturedGame();
    }
    
    loadMoreGames();
}

function loadMoreGames() {
    const startIndex = loadedGamesCount;
    const endIndex = Math.min(startIndex + gamesPerLoad, filteredGames.length);
    const gamesToAdd = filteredGames.slice(startIndex, endIndex);
    
    displayedGames.push(...gamesToAdd);
    loadedGamesCount = endIndex;
    
    renderGamesGrid();
    
    // Show/hide load more button
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    if (loadMoreBtn) {
        if (loadedGamesCount >= filteredGames.length) {
            loadMoreBtn.style.display = 'none';
        } else {
            loadMoreBtn.style.display = 'block';
        }
    }
}

function renderGamesGrid() {
    const gamesGrid = document.getElementById('gamesGrid');
    if (!gamesGrid) return;
    
    console.log('🎮 Rendering games grid with', displayedGames.length, 'games');
    
    if (displayedGames.length === 0) {
        gamesGrid.innerHTML = `
            <div class="no-games" style="text-align: center; padding: var(--space-32); grid-column: 1 / -1;">
                <h3>🔍 No games found</h3>
                <p>Try different search terms or categories to discover amazing games!</p>
            </div>
        `;
        return;
    }
    
    gamesGrid.innerHTML = displayedGames.map(game => createGameCard(game)).join('');
    
    // Add click listeners and animations
    gamesGrid.querySelectorAll('.game-card').forEach(card => {
        // Enhanced hover animations
        card.addEventListener('mouseenter', function() {
            if (typeof gsap !== 'undefined') {
                gsap.to(this, {
                    scale: 1.05,
                    y: -15,
                    duration: 0.4,
                    ease: 'power2.out'
                });
            } else {
                this.style.transform = 'translateY(-15px) scale(1.05)';
            }
        });
        
        card.addEventListener('mouseleave', function() {
            if (typeof gsap !== 'undefined') {
                gsap.to(this, {
                    scale: 1,
                    y: 0,
                    duration: 0.4,
                    ease: 'power2.out'
                });
            } else {
                this.style.transform = 'translateY(0) scale(1)';
            }
        });
        
        // Click to play
        card.addEventListener('click', function() {
            const gameId = this.dataset.gameId;
            playGame(gameId);
        });
    });
}

function createGameCard(game) {
    const stars = generateStars(game.rating);
    const isFavorite = favoriteGames.some(fav => fav.id === game.id);
    
    return `
        <div class="game-card ${game.trending ? 'trending' : ''}" data-game-id="${game.id}">
            <div class="game-card-image">
                <img src="${game.image}" alt="${game.title}" loading="lazy" 
                     onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgdmlld0JveD0iMCAwIDQwMCAzMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI0MDAiIGhlaWdodD0iMzAwIiBmaWxsPSIjMzc0MTUxIi8+Cjx0ZXh0IHg9IjIwMCIgeT0iMTUwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmaWxsPSIjOUI5OUE4IiBmb250LWZhbWlseT0iSW50ZXIiIGZvbnQtc2l6ZT0iMTQiPkdhbWUgSW1hZ2U8L3RleHQ+Cjwvc3ZnPg=='">
                ${game.trending ? '<div class="trending-badge" style="position: absolute; top: var(--space-8); left: var(--space-8); background: var(--color-warning); color: white; padding: var(--space-4) var(--space-8); border-radius: var(--radius-sm); font-size: var(--font-size-xs);">🔥 Trending</div>' : ''}
                ${isFavorite ? '<div class="favorite-badge" style="position: absolute; top: var(--space-8); right: var(--space-8); color: var(--color-error);">❤️</div>' : ''}
                <div class="game-card-overlay">
                    <div class="play-overlay">▶</div>
                </div>
            </div>
            <div class="game-card-content">
                <div class="game-card-category">${game.category}</div>
                <h3 class="game-card-title">${game.title}</h3>
                <div class="game-card-meta" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-8);">
                    <span class="difficulty-badge difficulty-${game.difficulty.toLowerCase()}" style="background: var(--color-bg-2); padding: var(--space-2) var(--space-6); border-radius: var(--radius-sm); font-size: var(--font-size-xs);">${game.difficulty}</span>
                    <span class="duration" style="color: var(--color-text-secondary); font-size: var(--space-sm);">${game.duration}min</span>
                </div>
                <div class="game-card-rating">
                    <span class="rating-stars" style="--rating: ${game.rating}">${stars}</span>
                    <span class="rating-number">${game.rating}</span>
                </div>
            </div>
        </div>
    `;
}

function generateStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    let stars = '';
    
    for (let i = 0; i < 5; i++) {
        if (i < fullStars) {
            stars += '★';
        } else if (i === fullStars && hasHalfStar) {
            stars += '☆';
        } else {
            stars += '☆';
        }
    }
    return stars;
}

// Rest of the functions remain the same as the original but with enhanced console logging...
function handleSearch(searchTerm) {
    filterGames(searchTerm.toLowerCase(), 
                document.getElementById('categoryFilter')?.value || 'All',
                document.getElementById('difficultyFilter')?.value || 'All');
}

function handleCategoryFilter(category) {
    filterGames(document.getElementById('gameSearch')?.value.toLowerCase() || '', 
                category,
                document.getElementById('difficultyFilter')?.value || 'All');
}

function handleDifficultyFilter(difficulty) {
    filterGames(document.getElementById('gameSearch')?.value.toLowerCase() || '', 
                document.getElementById('categoryFilter')?.value || 'All',
                difficulty);
}

function handleSort(sortBy) {
    switch (sortBy) {
        case 'title':
            filteredGames.sort((a, b) => a.title.localeCompare(b.title));
            break;
        case 'rating':
            filteredGames.sort((a, b) => b.rating - a.rating);
            break;
        case 'recent':
            filteredGames.sort((a, b) => b.releaseYear - a.releaseYear);
            break;
        case 'popular':
            filteredGames.sort((a, b) => b.trending - a.trending || b.rating - a.rating);
            break;
    }
    renderInitialGames();
}

function filterGames(searchTerm, category, difficulty) {
    filteredGames = allGames.filter(game => {
        const matchesSearch = !searchTerm || 
            game.title.toLowerCase().includes(searchTerm) ||
            game.description.toLowerCase().includes(searchTerm) ||
            game.category.toLowerCase().includes(searchTerm);
            
        const matchesCategory = category === 'All' || game.category === category;
        const matchesDifficulty = difficulty === 'All' || game.difficulty === difficulty;
        
        return matchesSearch && matchesCategory && matchesDifficulty;
    });
    
    updateGameCount();
    renderInitialGames();
}

function updateGameCount() {
    const gameCountEl = document.getElementById('gameCount');
    if (gameCountEl) {
        gameCountEl.textContent = `${filteredGames.length} games available`;
    }
}

function playGame(gameId) {
    const game = allGames.find(g => g.id === gameId);
    if (!game) return;
    
    console.log('🎮 Playing game:', game.title);
    
    // Add to history
    addToHistory(game);
    
    // Update user stats
    updateUserStats(game);
    
    // Check achievements
    checkAchievements(game);
    
    // Show game player modal
    showGamePlayer(game);
}

function addToHistory(game) {
    const existingEntry = gameHistory.find(h => h.gameId === game.id);
    
    if (existingEntry) {
        existingEntry.playCount++;
        existingEntry.lastPlayed = new Date().toISOString();
        existingEntry.totalDuration += Math.floor(Math.random() * 30) + 15; // Simulate play time
    } else {
        gameHistory.unshift({
            gameId: game.id,
            gameName: game.title,
            category: game.category,
            playCount: 1,
            lastPlayed: new Date().toISOString(),
            totalDuration: Math.floor(Math.random() * 30) + 15,
            completed: Math.random() > 0.7,
            rating: Math.random() > 0.5 ? +(Math.random() * 2 + 3).toFixed(1) : null
        });
    }
    
    // Keep only last 200 entries
    if (gameHistory.length > 200) {
        gameHistory = gameHistory.slice(0, 200);
    }
}

function updateUserStats(game) {
    if (!currentUser) return;
    
    const sessionTime = Math.floor(Math.random() * 60) + 30; // 30-90 minutes
    currentUser.totalPlayTime += sessionTime;
    currentUser.xp += Math.floor(sessionTime / 10) + 10; // XP based on play time
    currentUser.level = Math.floor(currentUser.xp / 100) + 1;
    
    // Update streak
    const today = new Date().toDateString();
    const lastPlay = currentUser.lastPlayDate ? new Date(currentUser.lastPlayDate).toDateString() : null;
    
    if (lastPlay !== today) {
        if (lastPlay === new Date(Date.now() - 86400000).toDateString()) {
            currentUser.currentStreak++;
        } else {
            currentUser.currentStreak = 1;
        }
        currentUser.lastPlayDate = new Date().toISOString();
    }
}

function toggleFavorite() {
    console.log('🤍 Toggle favorite functionality');
}

function showGamePlayer(game) {
    const modal = document.getElementById('gamePlayerModal');
    const title = document.getElementById('gamePlayerTitle');
    const iframe = document.getElementById('gameIframe');
    const loading = document.getElementById('gameLoading');
    const error = document.getElementById('gameError');
    
    if (!modal || !iframe) return;
    
    // Set title
    if (title) title.textContent = game.title;
    
    // Show modal
    showModal('gamePlayerModal');
    
    // Reset states
    if (loading) loading.style.display = 'flex';
    iframe.style.display = 'none';
    if (error) error.classList.add('hidden');
    
    // Set iframe source with delay for better UX
    setTimeout(() => {
        iframe.src = game.url;
        
        // Handle iframe load
        iframe.onload = () => {
            if (loading) loading.style.display = 'none';
            iframe.style.display = 'block';
            console.log('✅ Game loaded successfully');
        };
        
        // Fallback timeout
        setTimeout(() => {
            if (loading && loading.style.display !== 'none') {
                loading.style.display = 'none';
                iframe.style.display = 'block';
            }
        }, 8000);
        
    }, 1500);
}

function closeGamePlayerModal() {
    const iframe = document.getElementById('gameIframe');
    if (iframe) {
        iframe.src = '';
    }
    hideModal('gamePlayerModal');
}

function toggleFullscreen() {
    const iframe = document.getElementById('gameIframe');
    if (!iframe) return;
    
    if (iframe.requestFullscreen) {
        iframe.requestFullscreen();
    } else if (iframe.webkitRequestFullscreen) {
        iframe.webkitRequestFullscreen();
    } else if (iframe.msRequestFullscreen) {
        iframe.msRequestFullscreen();
    }
}

function initializeAchievements() {
    // Set welcome achievement as unlocked for all users
    const welcomeAchievement = userAchievements.find(a => a.id === 'welcome');
    if (welcomeAchievement) {
        welcomeAchievement.unlocked = true;
        welcomeAchievement.progress = 1;
    }
}

function checkAchievements(game) {
    if (!currentUser) return;
    
    // First game achievement
    if (gameHistory.length === 1) {
        unlockAchievement('first_game');
    }
    
    // Play count achievements
    const uniqueGames = new Set(gameHistory.map(h => h.gameId)).size;
    ['play_5', 'play_10', 'play_25', 'play_50', 'play_100'].forEach(achievementId => {
        const achievement = userAchievements.find(a => a.id === achievementId);
        if (achievement && !achievement.unlocked) {
            achievement.progress = uniqueGames;
            if (uniqueGames >= achievement.target) {
                unlockAchievement(achievementId);
            }
        }
    });
    
    // Time-based achievements
    const totalMinutes = currentUser.totalPlayTime;
    ['hour_1', 'hour_5', 'hour_10', 'marathon'].forEach(achievementId => {
        const achievement = userAchievements.find(a => a.id === achievementId);
        if (achievement && !achievement.unlocked) {
            achievement.progress = totalMinutes;
            if (totalMinutes >= achievement.target) {
                unlockAchievement(achievementId);
            }
        }
    });
    
    // Special time-based achievements
    const currentHour = new Date().getHours();
    if (currentHour >= 0 && currentHour < 6) {
        unlockAchievement('early_bird');
    }
    if (currentHour >= 22 || currentHour < 2) {
        unlockAchievement('night_owl');
    }
}

function unlockAchievement(achievementId) {
    const achievement = userAchievements.find(a => a.id === achievementId);
    if (!achievement || achievement.unlocked) return;
    
    achievement.unlocked = true;
    achievement.progress = achievement.target;
    
    console.log('🏆 Achievement unlocked:', achievement.name);
}

function updateProfile() {
    if (!currentUser) return;
    
    console.log('📊 Updating profile...');
    
    // Update profile info
    const profileUserName = document.getElementById('profileUserName');
    const userInitials = document.getElementById('userInitials');
    
    if (profileUserName) profileUserName.textContent = currentUser.username;
    if (userInitials) userInitials.textContent = currentUser.username.slice(0, 2).toUpperCase();
    
    // Calculate stats
    const totalGames = new Set(gameHistory.map(h => h.gameId)).size;
    const totalPlays = gameHistory.reduce((sum, game) => sum + game.playCount, 0);
    const completedGames = gameHistory.filter(h => h.completed).length;
    const achievementCount = userAchievements.filter(a => a.unlocked).length;
    const averageRating = gameHistory.filter(h => h.rating).length > 0 
        ? (gameHistory.filter(h => h.rating).reduce((sum, h) => sum + h.rating, 0) / gameHistory.filter(h => h.rating).length).toFixed(1)
        : '0.0';
    
    // Update stats
    updateElement('totalGamesPlayed', totalGames);
    updateElement('totalHoursPlayed', Math.floor(currentUser.totalPlayTime / 60));
    updateElement('achievementsEarned', achievementCount);
    updateElement('completedGames', completedGames);
    updateElement('currentStreak', currentUser.currentStreak);
    updateElement('averageRating', averageRating);
    updateElement('userLevel', currentUser.level);
    updateElement('userXP', currentUser.xp);
    
    // Update recent achievements
    updateRecentAchievements();
    
    // Update favorite games
    updateFavoriteGames();
}

function updateRecentAchievements() {
    const container = document.getElementById('recentAchievements');
    if (!container) return;
    
    const recentAchievements = userAchievements
        .filter(a => a.unlocked)
        .slice(0, 5);
    
    if (recentAchievements.length === 0) {
        container.innerHTML = '<div class="achievement-item"><span class="achievement-icon">🏆</span><span class="achievement-name">Welcome to GameSphere Pro!</span></div>';
        return;
    }
    
    container.innerHTML = recentAchievements.map(achievement => `
        <div class="achievement-item">
            <span class="achievement-icon">${achievement.icon}</span>
            <div class="achievement-details">
                <span class="achievement-name">${achievement.name}</span>
                <span class="achievement-rarity ${achievement.rarity.toLowerCase()}" style="font-size: var(--font-size-xs); color: var(--color-text-secondary);">${achievement.rarity}</span>
            </div>
        </div>
    `).join('');
}

function updateFavoriteGames() {
    const container = document.getElementById('favoriteGames');
    if (!container) return;
    
    if (favoriteGames.length === 0) {
        container.innerHTML = '<p class="empty-state">Play games to build your favorites list!</p>';
        return;
    }
    
    container.innerHTML = favoriteGames.slice(0, 4).map(game => `
        <div class="favorite-game-item" onclick="playGame('${game.id}')" style="display: flex; align-items: center; gap: var(--space-12); padding: var(--space-8); background: var(--color-bg-3); border-radius: var(--radius-base); cursor: pointer; margin-bottom: var(--space-8);">
            <img src="${game.image}" alt="${game.title}" style="width: 40px; height: 40px; border-radius: var(--radius-sm); object-fit: cover;" loading="lazy">
            <div class="favorite-info">
                <h5 style="margin: 0; font-size: var(--font-size-sm);">${game.title}</h5>
                <span style="color: var(--color-warning);">⭐ ${game.rating}</span>
            </div>
        </div>
    `).join('');
}

function updateHistory() {
    const tbody = document.getElementById('historyTableBody');
    if (!tbody) return;
    
    if (gameHistory.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; color: var(--color-text-secondary); padding: var(--space-32);">
                    🎮 No games played yet. Start your gaming journey!
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = gameHistory.map(entry => `
        <tr>
            <td>
                <div class="game-name-cell">
                    <strong>${entry.gameName}</strong>
                </div>
            </td>
            <td><span class="category-badge" style="background: var(--color-bg-4); padding: var(--space-2) var(--space-6); border-radius: var(--radius-sm); font-size: var(--font-size-xs);">${entry.category}</span></td>
            <td>${formatDate(entry.lastPlayed)}</td>
            <td><span class="play-count-badge" style="background: var(--color-bg-5); padding: var(--space-2) var(--space-6); border-radius: var(--radius-sm); font-size: var(--font-size-xs);">${entry.playCount}</span></td>
            <td>${entry.totalDuration || 0} min</td>
            <td>
                <span class="status-badge ${entry.completed ? 'status-completed' : 'status-played'}" style="padding: var(--space-4) var(--space-8); border-radius: var(--radius-sm); font-size: var(--font-size-xs); ${entry.completed ? 'background: var(--color-bg-3); color: var(--color-success);' : 'background: var(--color-bg-1); color: var(--color-primary);'}">
                    ${entry.completed ? '✅ Completed' : '🎮 Played'}
                </span>
            </td>
        </tr>
    `).join('');
}

function handleHistoryFilter(filter) {
    console.log('📊 Filtering history by:', filter);
    updateHistory();
}

function updateAchievements() {
    const container = document.getElementById('achievementsGrid');
    const progress = document.getElementById('achievementProgress');
    
    if (!container) return;
    
    const unlockedCount = userAchievements.filter(a => a.unlocked).length;
    const totalCount = userAchievements.length;
    
    if (progress) {
        progress.textContent = `${unlockedCount} / ${totalCount} Achievements Unlocked`;
    }
    
    container.innerHTML = userAchievements.map(achievement => `
        <div class="achievement-card ${achievement.unlocked ? 'unlocked' : 'locked'}">
            <div class="achievement-icon-large" style="font-size: var(--font-size-4xl); margin-bottom: var(--space-12);">${achievement.icon}</div>
            <h4 style="margin-bottom: var(--space-8);">${achievement.name}</h4>
            <p style="margin-bottom: var(--space-12); color: var(--color-text-secondary);">${achievement.description}</p>
            <div class="achievement-rarity ${achievement.rarity.toLowerCase()}" style="margin-bottom: var(--space-8); font-size: var(--font-size-xs); text-transform: uppercase; letter-spacing: 0.1em;">${achievement.rarity}</div>
            ${!achievement.unlocked && achievement.target > 1 ? 
                `<div class="achievement-progress-bar" style="background: var(--color-bg-1); border-radius: var(--radius-full); height: 8px; margin-bottom: var(--space-8); overflow: hidden;">
                    <div class="progress-fill" style="height: 100%; background: var(--color-primary); width: ${(achievement.progress / achievement.target * 100)}%; transition: width 0.3s;"></div>
                </div>
                <span class="progress-text" style="font-size: var(--font-size-xs); color: var(--color-text-secondary);">${achievement.progress}/${achievement.target}</span>` : ''
            }
            ${achievement.unlocked ? '<div class="unlocked-badge" style="color: var(--color-success); font-weight: var(--font-weight-semibold);">✅ Unlocked</div>' : '<div class="locked-badge" style="color: var(--color-text-secondary);">🔒 Locked</div>'}
        </div>
    `).join('');
}

function clearHistory() {
    if (confirm('Are you sure you want to clear your game history? This action cannot be undone.')) {
        gameHistory = [];
        updateHistory();
        updateProfile();
        console.log('🗑️ Game history cleared');
    }
}

function updateElement(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        console.log(`📺 Showing modal: ${modalId}`);
        modal.classList.remove('hidden');
        setTimeout(() => {
            modal.classList.add('active');
            
            // Start EPIC VFX for auth modal
            if (modalId === 'authModal') {
                epicVFXActive = true;
                startBGMSimulation();
                setupEpicInputHandlers(); // Re-setup handlers for the modal
                console.log('🎬 EPIC VFX ACTIVATED for login modal!');
            }
        }, 10);
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        console.log(`📺 Hiding modal: ${modalId}`);
        modal.classList.remove('active');
        
        // Stop EPIC VFX for auth modal
        if (modalId === 'authModal') {
            epicVFXActive = false;
            stopBGMSimulation();
            console.log('🎬 EPIC VFX DEACTIVATED');
        }
        
        setTimeout(() => modal.classList.add('hidden'), 300);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', init);

// Enhanced window event listeners
window.addEventListener('resize', () => {
    const canvas = document.getElementById('particleCanvas');
    if (canvas) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
});

// Prevent default drag behavior on images
document.addEventListener('dragstart', (e) => {
    if (e.target.tagName === 'IMG') {
        e.preventDefault();
    }
});

// Console welcome message with EPIC VFX
console.log(`
🎮 GameSphere Pro - Ultimate Gaming Platform with EPIC VFX
👨‍💻 Developed by RAVINDRA REDDY
📅 Copyright 2025
✨ Premium gaming experience with 1000+ games
🚀 Powered by modern web technologies
💥 FEATURING EPIC LOGIN VFX SYSTEM!
⚡ Shooting effects, racing animations, BGM simulation
🔥 Screen shake, explosions, and cinematic experience
🎬 The most EPIC login page ever created!
`);

// Export for debugging (development only)
if (typeof window !== 'undefined') {
    window.GameSpherePro = {
        currentUser,
        allGames,
        gameHistory,
        userAchievements,
        developer: 'RAVINDRA REDDY',
        epicVFXActive,
        triggerBassDropEffect,
        triggerVictoryExplosion,
        triggerLoginExplosion,
        introCompleted
    };
}